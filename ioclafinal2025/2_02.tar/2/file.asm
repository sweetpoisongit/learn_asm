section .data
    str_a db "D0n't w0RrY", 10, 0
    str1_d db "Bigg String", 10, 0
    str2_d db "Smol", 0


section .text
global main

; TODO a: Implement `void lowercase(char *src)`
; Change all uppercase characters from `src` to lowercase.

lowercase:
    push ebp
    mov ebp, esp

    leave
    ret


; TODO b: Implement `int ispow(int n)`
; Return 1 if n is a power of 4, 0 otherwise.

ispow:
    push ebp
    mov ebp, esp

    leave
    ret


; TODO c: Implement `int myabs(int n)`
; Return -n if n < 0, n otherwise

myabs:
    push ebp
    mov ebp, esp

    leave
    ret


; TODO d: Implement `void strswap(char *s1, char *s2, int size1, int size2)`

strswap:
    push ebp
    mov ebp, esp

    leave
    ret


main:
    push ebp
    mov ebp, esp

    ; TODO a: Call `lowercase` using `str_a` as argument.
    ; You must print the resulted string.


    ; TODO b: Call `ispow()` using 256 and 8 as arguments.
    ; Print the result both times.


    ; TODO c: Call `myabs()` using both a negative and a positive argument.
    ; Print the results.


    ; TODO d: Call `strswap` using `str1_d` and `str2_d` as arguments.
    ; Print both strings after the function ends.


    ; Return 0.
    xor eax, eax
    leave
    ret
