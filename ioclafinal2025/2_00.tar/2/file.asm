section .rodata
format: db "String is: %s", 10, 0
format_len: db "String len is: %d", 10, 0
format_char: db "Character %c appears %d times", 10, 0
change_me: db "No OnE cAn cHaNgE mE!!!", 10, 0
change_len: dd 24

section .bss
challenge_accepted: resb 25

section .data

mantra: db "Biblioteca, nu librarie!", 10, 0
mantra_len: dd 26

section .text
global main

numc:
	push ebp
	mov ebp, esp

	; TODO c: complete the `void numc(char *s, char c)` function

	leave
	ret


switch:
	push ebp
	mov ebp, esp

	mov esi, [ebp + 8] ; change_me
	mov ecx, [ebp + 12] ; change_me_len

	; TODO d: Use `islower`, `isupper`, `tolower`, `toupper` to modify change_me

	leave
	ret

main:
	push ebp
	mov ebp, esp

	; TODO a: Allocate "I <3 IOCLA!" on the stack. Print the result.
	; You can use the `format` and `format_len` strings for printf


	; TODO b: Call malloc to allocat 100 bytes and copy the content of the `matra`
	; string in the newly allocated buffer


	; TODO c: Complete the `numc` function and test it using `mantra` as a string
	; and `i` as a character

  	; TODO d: Complete the `switch` function
	push dword [change_len]
	push change_me
	call switch
	add esp, 8


	; Return 0.
	xor eax, eax
	leave
	ret
