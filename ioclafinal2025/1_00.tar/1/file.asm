%include "printf32.asm"


; structure for a binary_fun entry
struc binary_fun_t
	number: resd 1	; the number
	mask: resd 1	; the mask that should be applied to the number using the logical AND operation
	maskedn: resd 1	; the number with the applied mask
	negate: resd 1	; the negate value of number
endstruc

section .bss
ave_string: resb 13

section .data

binary_funs:
	istruc binary_fun_t
		at number, dd 0xAABBCCDD
		at mask, dd 0xFFFF0000
		at maskedn, dd 0
		at negate, dd 0
	iend

binary_vec: dw 0x1, 0x2, 0x3, 0x6, 0x9, 0xff
binary_len: dd 6

init_string: db 'IOCLA Rullz!', 0
string_len: dd 12
N: db 5

section .text
extern printf
extern exit
global main

ave:
	push ebp
	mov ebp, esp

	PRINTF32 `Before transformation: %s\n\x0`, init_string

	mov esi, init_string
	mov edi, ave_string

	; TODO c: Apply the following transformation for each character of init_string
	; newc = (c - 'A' + N ) % 31 + 'A'


	PRINTF32 `After transformation: %s\n\x0`, ave_string

	leave
	ret

exit42:
	push ebp
	mov ebp, esp

	mov eax, [ebp + 8] ; 1st param

	; TODO d: if eax is a multiple of 42, then exit 42

	mov esi, [ebp + 8]
	PRINTF32 `%d is not a multiple of 42.\n\x0`, esi
	leave
	ret

main:
	push ebp
	mov ebp, esp


	; TODO a: Compute fields `maskedn` and `negate`
	; maskedn = number & mask
        ; negate = not number

	; TODO a: Print structure fields

	; TODO b: Count number of elements with the second least significant bit equal to 1

	xor ebx, ebx
	PRINTF32 `No of elements: %d\n\x0`, ebx

	; TODO c: Complete function `ave`

	pusha
	call ave
	popa

	; TODO d: Complete function exit42
	push dword 2
	call exit42
	add esp, 4

	push dword 42
	call exit42
	add esp, 4

	; Return 0.
	xor eax, eax
	leave
	ret
